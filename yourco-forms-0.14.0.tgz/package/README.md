# @yourco/forms

Renders a builder-exported form schema in a React app, validates it, and posts it to your API.

## Images served by your app

An `image` block's source is either an `https://` URL or a path on your own server starting with a
single `/` (e.g. `/images/logo.png`); anything else is not shown. If your app is served under a
sub-path, pass it as `assetBase` so those paths load from under it — with Vite:

```jsx
<FormRenderer schema={schema} endpoint="/api/submit" assetBase={import.meta.env.BASE_URL} />
```

`https://` sources ignore `assetBase`. Images are requested with `referrerPolicy="no-referrer"`.

## Server-side use

Never trust the browser's payload. On your server, pass it to `prepareSubmission` from
`@yourco/forms/core` (no React needed) with the same schema the form was rendered from:

```js
import { prepareSubmission } from '@yourco/forms/core';

const result = prepareSubmission(schema, body);

if (!result.ok) {
  return res.status(422).json({ errors: result.errors }); // [{ blockId, message }]
}
if (result.versionMismatch) {
  log.warn('submission built against a different form version', body.formId, body.formVersionId);
}
store({ ...body, answers: result.answers }); // store these answers, never body.answers
```

`prepareSubmission`:

- **checks the schema** and throws if it is malformed (unknown type, bad condition, unsupported
  `schemaVersion`) — a fault in your schema, not in the payload;
- **validates** every visible question: required, formats, allowed options. Free-text answers (short,
  long, email, phone, link) must be strings of at most `MAX_FREE_TEXT_LENGTH` (20,000) characters;
  email, phone and link formats are checked on the trimmed text;
- **treats whitespace-only free text as unanswered**: a required one is rejected, and an optional one
  comes back as `{ state: 'empty' }`. Any other text comes back exactly as sent — never trimmed;
- **returns the answers to store**: visible answerable questions only. Answers to hidden or unknown
  questions are stripped, never a reason to reject;
- **normalises numbers**: a numeric string such as `"500"` answering a number, scale or rating
  question comes back as `500`. A non-numeric string is still rejected;
- **flags `versionMismatch`** when the payload's `formId` or `formVersionId` differs from the schema's.
  Whether to refuse such a payload is your call.

The lower-level pieces are exported too, if you need them separately: `assertSchemaIntegrity`,
`validateSubmission`, `getSubmittableAnswers`.

**Keep bodies out of request logs.** Submission bodies — and, if you store server-mode drafts, draft
bodies — carry the respondent's answers, which are PHI. Don't write them to request or access logs,
error reports or analytics; log ids such as `formId`, `formVersionId` and `idempotencyKey` instead.
