# @yourco/forms

Renders a builder-exported form schema in a React app, validates it, and posts it to your API.

## Images served by your app

An `image` block's source is either an `https://` URL or a path on your own server starting with a
single `/` (e.g. `/images/logo.png`); anything else is not shown. If your app is served under a
sub-path, pass it as `assetBase` so those paths load from under it — with Vite:

```jsx
<FormRenderer schema={schema} endpoint="/api/submit" assetBase={import.meta.env.BASE_URL} />
```

`https://` sources ignore `assetBase`. Images are requested with `referrerPolicy="no-referrer"`.

## Video

A `video` block shows a YouTube or Vimeo link in that service's player, or an `.mp4` / `.webm` file
in the browser's own player. Files follow the same source rule as images (an `https://` URL, or a
path starting with a single `/`, loaded from under `assetBase`). Anything else is not shown. Videos
never autoplay.

**Content Security Policy.** If your app sends a CSP, allow the two players, and wherever your own
video files live:

```
frame-src https://www.youtube-nocookie.com https://player.vimeo.com;
media-src 'self';
```

(Add any other host you serve `.mp4` / `.webm` files from to `media-src`.)

- **Captions** are the author's responsibility: add them on YouTube or Vimeo. Video files have no
  caption support yet.
- **Suggestions on YouTube:** the player is loaded with `rel=0`, which only limits the suggestions
  shown at the end of a video to the same channel. It does not remove them.
- **Referrer for video files:** the players are sent only your site's origin, never the page path.
  A `<video>` element has no referrer setting of its own, so a video file on another host is
  requested with your page's referrer policy. Keep `Referrer-Policy: strict-origin-when-cross-origin`
  (the browser default) or stricter so the page path is never sent.

## Audio

An `audio` block plays an `.mp3`, `.m4a`, `.ogg` or `.wav` file in the browser's own player, full
width up to the form's width. Sources follow the same rule as images (an `https://` URL, or a path
starting with a single `/`, loaded from under `assetBase`); anything else — including streaming
services such as Spotify — is not shown, and neither is a file that fails to load. Audio never
autoplays, loops or starts muted.

**Content Security Policy.** If your app sends a CSP, allow wherever your audio files live:

```
media-src 'self';
```

(Add any other host you serve audio files from.)

- **Referrer:** an `<audio>` element has no referrer setting of its own, so an audio file on
  another host is requested with your page's referrer policy. Keep
  `Referrer-Policy: strict-origin-when-cross-origin` (the browser default) or stricter so the page
  path is never sent.
- **Transcripts:** prerecorded audio needs a text alternative to meet WCAG 2.1 AA (1.2.1). That is
  the form author's responsibility: put a transcript in a `text` block next to the clip.

## Complete answers: `completeRequired`

`completeRequired: true` asks for a question to be answered **in full**. It applies to two types
only:

- **`matrix`:** every row must be answered.
- **`ranking`:** every option must be ranked.

On those two it also makes the question **required**: an empty answer gets "… is required.", and
the question shows the required marker, whatever `required` says. A partial answer gets "Answer
every row of …" or "Rank every option in …".

On **every other type it is ignored**, like any other setting that does not apply there: a
short-text question with `completeRequired: true` and `required: false` is optional. The browser
and `prepareSubmission` apply the same rule.

## Server-side use

Never trust the browser's payload. On your server, pass it to `prepareSubmission` from
`@yourco/forms/core` (no React needed) with the same schema the form was rendered from:

```js
import { prepareSubmission } from '@yourco/forms/core';

const result = prepareSubmission(schema, body);

if (!result.ok) {
  return res.status(422).json({ errors: result.errors }); // [{ blockId, message, path }]
}
if (result.versionMismatch) {
  log.warn('submission built against a different form version', body.formId, body.formVersionId);
}
store({ ...body, answers: result.answers }); // store these answers, never body.answers
```

`prepareSubmission`:

- **checks the schema** and throws if it is malformed (unknown type, bad condition, unsupported
  `schemaVersion`) — a fault in your schema, not in the payload;
- **validates** every visible question: required, formats, allowed options. Options are coded
  (`{ code, label }`): the browser sends **codes only**, and membership compares codes exactly as
  stored. A label, a code in the wrong case, or a `{ code, label }` object in place of a code is
  rejected with the usual message ("Select a valid option.", or "Invalid answer." for a matrix). Free-text answers (short,
  long, email, phone, link) must be strings of at most `MAX_FREE_TEXT_LENGTH` (20,000) characters;
  email, phone and link formats are checked on the trimmed text;
- **treats whitespace-only free text as unanswered**: a required one is rejected, and an optional one
  comes back as `{ state: 'empty' }`. Any other text comes back exactly as sent — never trimmed;
- **returns the answers to store**: visible answerable questions only. Answers to hidden or unknown
  questions are stripped, never a reason to reject;
- **normalises numbers**: a numeric string such as `"500"` answering a number, scale or rating
  question comes back as `500`. A non-numeric string is still rejected;
- **returns coded answers with their labels**, looked up from the schema you pass — never from the
  request — so stored submissions are readable without the schema (see below). Labels are plain
  text; treat them as data and escape them wherever you display them;
- **rejects a malformed answer value**: every answer must be `{ state: 'empty' }` or
  `{ state: 'answered', value }`. Anything else under a visible question's id — `null`, a bare value,
  a missing or unknown `state` — is rejected with "Invalid answer.", whatever the question type;
- **checks grids cell by cell** (see below): a required column must be answered in every row, and
  each missing cell is its own error;
- **handles repeating groups**: a repeating group's answer is an array of instance objects under its
  own id, each built by these same rules (nested repeating groups are arrays inside it). Every rule
  above applies per instance. A visible repeating group whose value is not an array, has an
  instance that is not an object, or has fewer than `minOccurs` / more than `maxOccurs` instances is
  rejected with "Invalid answer.";
- **runs your own validators** when you pass them as `prepareSubmission(schema, body, { validators })`
  (see [Custom validation](#custom-validation));
- **flags `versionMismatch`** when the payload's `formId` or `formVersionId` differs from the schema's.
  Whether to refuse such a payload is your call.

### What `prepareSubmission` returns for coded options

`choice`, `dropdown`, `checkbox`, `multiselect`, `ranking` and `matrix` answers come back labelled.
Every other answer is returned as it was (after the normalisation above):

```json
{
  "smoker":   { "state": "answered", "value": { "code": "former", "label": "Former smoker" } },
  "symptoms": { "state": "answered", "value": [
    { "code": "F32.1", "label": "Low mood" },
    { "code": "sleep", "label": "Poor sleep" }
  ] },
  "phq":      { "state": "answered", "value": [
    { "row": { "code": "interest", "label": "Little interest" }, "column": { "code": "several", "label": "Several days" } }
  ] },
  "age":      { "state": "answered", "value": 42 }
}
```

- `choice`, `dropdown`: `{ code, label }`.
- `checkbox`, `multiselect`, `ranking`: `[{ code, label }, …]`, in the submitted order.
- `matrix`: `[{ row, column }, …]`, answered rows only, in the schema's row order.
- `grid`: `[{ row, cells: [{ column, value }, …] }, …]` (type `GridRowAnswer[]`): answered rows
  only, in row order, each with its answered cells in column order. A radio or dropdown cell's
  `value` is `{ code, label }`; a text cell's is the text as typed. A grid with no answered cell
  comes back as `{ state: 'empty' }`.
- The same applies inside every instance of a repeating group. The TypeScript type is
  `PreparedAnswers`.

### Grids

A `grid` is a table of fixed rows and typed columns (`radio`, `dropdown` or `text`), one answer per
cell. The browser sends `{ [rowCode]: { [columnCode]: string } }`: a choice cell holds an option code
of its column, a text cell its text; empty cells and empty rows are left out.

- **Required is per column**: a column with `required: true` must be answered in every row. The
  grid's own `required` and `completeRequired` are ignored.
- **Errors are per cell**: a missing required cell is `{ message: "Required.", path: [..., gridId,
  rowCode, columnCode] }`, one per cell. A choice cell holding something that is not a code of its
  column gets "Select a valid option."; a text cell over 20,000 characters, "Your answer is too
  long."; a value of the wrong shape, or an unknown row or column code, one "Invalid answer." at
  `[..., gridId]`.
- **A grid is never a condition source**; it can carry its own `enableWhen`.
- In the browser, the error summary shows one entry per required column with missing cells —
  `"Substance use": answer "Frequency" in every row (3 missing).` — linking to the first one.
- Below the stylesheet's narrow breakpoint (40rem) each row shows as a card. Class names:
  `yf-grid`, `yf-grid-row`, `yf-grid-card`, `yf-grid-cell`, `yf-grid-cell-label`,
  `yf-grid-cell--invalid`, `yf-grid-column--required`.

Each error's `path` locates it: block ids and 0-based instance positions from the root, e.g.
`["patients", 1, "payments", 0, "amount"]`, or just `[blockId]` outside any repeating group.

The lower-level pieces are exported too, if you need them separately: `assertSchemaIntegrity`,
`validateSubmission`, `getSubmittableAnswers`.

`getVisibleBlockIds` and `getDisplayedBlockIds` cover the **root level only**: every block outside
a repeating group, and the repeating groups themselves. Blocks inside a repeating group are judged
per instance — the same question can be visible in one instance and hidden in another — so they
are not in these sets. `validateSubmission`, `getSubmittableAnswers` and `prepareSubmission` already
apply visibility per instance.

**Keep bodies out of request logs.** Submission bodies — and, if you store server-mode drafts, draft
bodies — carry the respondent's answers, which are PHI. Don't write them to request or access logs,
error reports or analytics; log ids such as `formId`, `formVersionId` and `idempotencyKey` instead.

## Custom validation

Your own checks on any answerable question, written as JavaScript functions in your code. Nothing
about them goes in the schema or the builder.

**Pass the same validators to `prepareSubmission`, or they can be bypassed.** The browser's checks
are only a convenience: anyone can post straight to your endpoint. Keep the validators in one module
and import it in both places:

```js
// validators.js — imported by the page and by the backend
export const validators = [
  {
    field: 'mrn', // block id of an answerable question
    validate: ({ value }) => (/^MRN\d{6}$/.test(value) ? null : 'Enter the MRN as MRN followed by 6 digits.'),
  },
  {
    field: 'discharged',
    // Dates are "YYYY-MM-DD", so they compare as strings.
    validate: ({ value, answers }) =>
      answers.admitted && value <= answers.admitted ? 'Discharge must be after admission.' : null,
  },
];
```

```jsx
// The page
import { validators } from './validators.js';

<FormRenderer schema={schema} endpoint="/api/submissions" validators={validators} />;
```

```js
// The backend
import { prepareSubmission } from '@yourco/forms/core';
import { validators } from './validators.js';

const result = prepareSubmission(schema, body, { validators });
```

`validateSubmission(schema, answers, { validators })` and `getCompletedPageIds(…, { validators })`
take them too.

**What a validator receives:** `{ value, answers, field, path }`.

- **Built-in checks run first, so a validator always receives a well-formed value.** It runs only
  when the question is visible, answered, and passes every built-in check (format, allowed options,
  min/max, `completeRequired`, a grid's required columns). It never sees an empty or invalid answer.
- `value` is in payload form, with codes and never labels: numbers as numbers, dates as
  `"YYYY-MM-DD"`, `checkbox`, `multiselect` and `ranking` as arrays of codes, `matrix` as
  `{ [rowCode]: columnCode }`, `grid` as `{ [rowCode]: { [columnCode]: string } }`.
- `answers` holds the other visible, answered, valid questions it may depend on, by block id: the
  same repeat instance, every enclosing instance, and questions outside any repeat. Never other
  instances.
- Inside a repeating group it runs **once per instance**. `path` is the same as the error's
  `path`, e.g. `["patients", 1, "mrn"]`.
- `value` and `answers` are copies, so changing them has no effect.

**What it returns:** an error message, or `null` / `undefined` when the answer is valid.

- The message is trimmed and shown as **plain text**, never HTML. It appears on the question and in
  the error summary, with the instance prefix ("Patient 2: …"). On a grid, it is shown under the
  grid as a whole.
- Several validators may name one field. They run in array order, and every error is reported. The
  browser shows an identical message only once per question.
- Anything else fails closed: a throw, an empty or whitespace-only string, a number, an object or a
  Promise. The question shows **"This answer couldn't be checked."** and can't be submitted. The
  browser logs the real error with `console.error`, naming the field. On the server, the error
  carries it as `cause` for you to log. `cause` is non-enumerable, so it never appears in
  `JSON.stringify(errors)`.

**Rules for validators:**

- **They must be pure and fast.** In a paged form they run on every render (each keystroke), and on
  flagged questions in any form. Don't log, count or cache anything from inside one.
- **They must not use `window`, `document` or anything else on the page, or make network calls.**
  The same code runs on your server, where none of that exists.
- **Errors only, and synchronous only, in this version.** Warnings and async validators (for
  example, an MRN lookup) are not supported. A returned Promise counts as a failure.
- The `validators` array is checked at mount and whenever you pass a different array, and
  `prepareSubmission` checks it on every call. Each entry must be `{ field, validate }`, where
  `field` is the id of an answerable question and `validate` is a function. Anything else throws a
  `TypeError` naming the entry. Validators are always function references. Nothing is ever
  evaluated from text.
- **`prepareSubmission` is JavaScript**, so in this version only a Node (or other JavaScript)
  backend can enforce validators. A backend in another language can't run them.
