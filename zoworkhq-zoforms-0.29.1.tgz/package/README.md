# @zoworkhq/zoforms

Renders a form schema exported from the ZoForms builder in a React app, validates it, and posts it to
your API.

## Quick start

```sh
npm install @zoworkhq/zoforms
```

It needs `react` and `react-dom` 18 or 19. On a server, `/core` needs Node 20 or later.

Show the form:

```jsx
import { FormRenderer } from '@zoworkhq/zoforms/react';
import '@zoworkhq/zoforms/styles.css';
import schema from './intake-schema.json';

export function IntakePage() {
  return (
    <main>
      <h1>{schema.title}</h1>
      <FormRenderer schema={schema} endpoint="/api/submit" />
    </main>
  );
}
```

Receive it. This example uses Express; any server works the same way:

```js
import { readFileSync } from 'node:fs';
import express from 'express';
import { prepareSubmission } from '@zoworkhq/zoforms/core';

const schema = JSON.parse(readFileSync('./intake-schema.json', 'utf8'));
const app = express();
app.use(express.json({ limit: '1mb' }));

app.post('/api/submit', async (req, res) => {
  const result = prepareSubmission(schema, req.body);
  if (result.ok === false) return res.status(422).json({ errors: result.errors });

  // A retry carries the same key: store each submission once. alreadyStored and store are yours.
  const { submission } = result;
  if (!(await alreadyStored(submission.idempotencyKey))) await store(submission);
  res.json({ ok: true });
});

app.listen(3000);
```

The package has three entry points: `@zoworkhq/zoforms/react`, `@zoworkhq/zoforms/core` and
`@zoworkhq/zoforms/styles.css`. There is no bare `@zoworkhq/zoforms` import.

## Showing the form

The renderer shows the form's questions, not its title. Your page shows the schema's `title`, and
its `description` when the author wrote one (plain text, never HTML), and owns the page's `h1`.
The renderer's own headings start at `h2`: group labels in a single-page form, page titles in a
paged one.

```jsx
<main>
  <h1>{schema.title}</h1>
  {schema.description && <p>{schema.description}</p>}
  <FormRenderer schema={schema} endpoint="/api/submit" />
</main>
```

## `FormRenderer` props

| Prop | Type | Default | What it does |
|---|---|---|---|
| `schema` | `FormSchema` | required | The form, as the builder exported it. |
| `endpoint` | `string` | required | Where the form is posted. An absolute URL must be `https://`, or `http://` on `localhost` or `127.0.0.1`; anything else is refused. A relative path uses the page's own protocol. |
| `credentials` | `'omit' \| 'same-origin' \| 'include'` | `'same-origin'` | Passed to `fetch`. |
| `getAuthHeaders` | `() => Record<string, string> \| Promise<…>` | | Extra request headers, asked for on every attempt, so a long-open form never sends an expired token. |
| `onSuccess` | `(response: Response) => void` | | The endpoint answered with a 2xx. |
| `onError` | `(error: unknown) => void` | | A submit failed: a non-2xx answer, a network error or a timeout. Only ever about submitting. |
| `timeoutMs` | `number` | `30000` | How long a submit may take. |
| `drafts` | `DraftsOptions` | | How progress is kept: see [Drafts and data in the browser](#drafts-and-data-in-the-browser). |
| `onDraftProblem` | `(problem: DraftProblem) => void` | | A draft couldn't be used, loaded, saved or deleted. The form carries on. |
| `assetBase` | `string` | | Where your app serves its own files: see [Files served by your app](#files-served-by-your-app). |
| `validators` | `readonly FieldValidator[]` | | Your own checks: see [Custom validation](#custom-validation). Pass the same array to `prepareSubmission`. |
| `onRenderError` | `(error: unknown, info: { componentStack?: string }) => void` | | The form couldn't be shown: see [Errors](#errors). |

## The posted body

The form posts JSON to `endpoint` with `Content-Type: application/json`:

```json
{
  "idempotencyKey": "6f1c1e0a-3c55-4a54-9d0e-6e6f6f1f7b3a",
  "schemaVersion": 2,
  "formId": "intake",
  "formVersionId": "v3",
  "submittedAt": "2026-10-30T09:15:00.000Z",
  "answers": { "name": { "state": "answered", "value": "Ada" }, "notes": { "state": "empty" } },
  "derived": {}
}
```

- `answers` holds visible questions only. Each is `{ "state": "empty" }` or
  `{ "state": "answered", "value": … }`; a repeating group is an array of objects like `answers`.
- `idempotencyKey` stays the same across retries and after a refresh, and changes only when the
  respondent clears the form or starts over.
- `formVersionId` is the version of the form the respondent filled in. Your server keeps it as
  `answeredFormVersionId`.
- `derived` is always empty. Scores are calculated on your server, never taken from the browser.

**The response.** Any 2xx means the form was received: the respondent sees "Form submitted
successfully." Anything else, or no answer within `timeoutMs`, is a failure: the respondent sees
"Submission failed. Your answers have been kept — please try again." and can send it again, with the
same key. The response body is never read, so to show your own message use `onSuccess` or `onError`.

## Server-side use

Never trust the browser's payload. On your server, pass it to `prepareSubmission` from
`@zoworkhq/zoforms/core` (no React needed) with the same schema the form was rendered from:

```js
import { prepareSubmission } from '@zoworkhq/zoforms/core';

const result = prepareSubmission(schema, body);

if (result.ok === false) {
  return res.status(422).json({ errors: result.errors }); // [{ blockId, message, path }]
}
const { submission } = result;
if (result.versionMismatch) {
  log.warn('filled in on another form version', submission.answeredFormVersionId, submission.formVersionId);
}
if (!(await alreadyStored(submission.idempotencyKey))) await store(submission);
```

**Store only `result.submission`, never `body`.** It holds:

- your schema's `formId`, `formVersionId` and `schemaVersion`;
- `answeredFormVersionId`: the version of the form the respondent filled in, which is the body's
  `formVersionId` exactly as sent. It's always there, and it differs from `formVersionId` only when
  `versionMismatch` is true, so a stored record always shows which version was answered;
- the checked `idempotencyKey` and `submittedAt`;
- the answers and the scores.

Nothing else from the request reaches it, the body's `schemaVersion` included. `submittedAt` comes
from the respondent's clock, so record your own receipt time too.

**Dedupe on `idempotencyKey`.** A submit that reached you but whose response never got back is sent
again with the same key. Store it once, and answer a repeat with a 2xx.

`prepareSubmission`:

- **checks the schema** and throws if it is malformed (unknown type, bad condition, unsupported
  `schemaVersion`) — a fault in your schema, not in the payload;
- **validates** every visible question: required, formats, allowed options. Options are coded
  (`{ code, label }`): the browser sends **codes only**, and membership compares codes exactly as
  stored. A label, a code in the wrong case, or a `{ code, label }` object in place of a code is
  rejected with the usual message ("Select a valid option.", or "Invalid answer." for a matrix). Free-text answers (short,
  long, email, phone, link) must be strings of at most `MAX_FREE_TEXT_LENGTH` (20,000) characters;
  email, phone and link formats are checked on the trimmed text;
- **treats whitespace-only free text as unanswered**: a required one is rejected, and an optional one
  comes back as `{ state: 'empty' }`. Any other text comes back exactly as sent — never trimmed;
- **checks the request itself**: a body that isn't an object with an `answers` object, an
  `idempotencyKey` that isn't 1–128 characters of A–Z, a–z, 0–9, `-` and `_`, a `submittedAt` that
  isn't an ISO-8601 UTC time, or a `formVersionId` that isn't text of 1–256 characters (not blank;
  your schema's own `formVersionId` is accepted whatever its length) is rejected with an error whose
  `blockId` is `''`. It never throws on a bad body;
- **rebuilds every answer it returns**: visible answerable questions only, each as
  `{ state: 'empty' }` or `{ state: 'answered', value }` with the value built afresh for its type, so
  no extra key survives. Answers to hidden or unknown questions are stripped, never a reason to reject;
- **normalises numbers**: a plain decimal string such as `"500"` answering a number, scale or rating
  question comes back as `500`. Anything else is rejected: hex, `"Infinity"`, `"1e400"`, booleans,
  arrays;
- **holds dates and times to strings**: a date is a real calendar `YYYY-MM-DD`, a time is `HH:MM` or
  `HH:MM:SS` from `00:00` to `23:59`;
- **returns coded answers with their labels**, looked up from the schema you pass — never from the
  request — so stored submissions are readable without the schema (see below). Labels are plain
  text; treat them as data and escape them wherever you display them;
- **rejects a malformed answer value**: every answer must be `{ state: 'empty' }` or
  `{ state: 'answered', value }`. Anything else under a visible question's id — `null`, a bare value,
  a missing or unknown `state` — is rejected with "Invalid answer.", whatever the question type;
- **checks grids cell by cell** (see below): a required column must be answered in every row, and
  each missing cell is its own error;
- **handles repeating groups**: a repeating group's answer is an array of instance objects under its
  own id, each built by these same rules (nested repeating groups are arrays inside it). Every rule
  above applies per instance. A visible repeating group whose value is not an array, has an
  instance that is not an object, or has fewer than `minOccurs` / more than `maxOccurs` instances is
  rejected with "Invalid answer.". With no `maxOccurs` the limit is 1,000 (`DEFAULT_MAX_OCCURS`), and
  too many instances are refused on the count alone, before any is read;
- **runs your own validators** when you pass them as `prepareSubmission(schema, body, { validators })`
  (see [Custom validation](#custom-validation));
- **calculates scores** and returns them in `submission.scores` and `derived.scores` (see
  [Scoring](#scoring)). Anything score-like in the request is ignored;
- **flags `versionMismatch`** when the payload's `formId` or `formVersionId` differs from the schema's.
  Whether to refuse such a payload is your call. If you accept it, `submission.answeredFormVersionId`
  records the version that was filled in.

### What `prepareSubmission` returns for coded options

`choice`, `dropdown`, `checkbox`, `multiselect`, `ranking` and `matrix` answers come back labelled.
Every other answer is returned as it was (after the normalisation above):

```json
{
  "smoker":   { "state": "answered", "value": { "code": "former", "label": "Former smoker" } },
  "symptoms": { "state": "answered", "value": [
    { "code": "F32.1", "label": "Low mood" },
    { "code": "sleep", "label": "Poor sleep" }
  ] },
  "phq":      { "state": "answered", "value": [
    { "row": { "code": "interest", "label": "Little interest" }, "column": { "code": "several", "label": "Several days" } }
  ] },
  "age":      { "state": "answered", "value": 42 }
}
```

- `choice`, `dropdown`: `{ code, label }`.
- `checkbox`, `multiselect`, `ranking`: `[{ code, label }, …]`, in the submitted order.
- `matrix`: `[{ row, column }, …]`, answered rows only, in the schema's row order.
- `grid`: `[{ row, cells: [{ column, value }, …] }, …]` (type `GridRowAnswer[]`): answered rows
  only, in row order, each with its answered cells in column order. A radio or dropdown cell's
  `value` is `{ code, label }`; a text cell's is the text as typed. A grid with no answered cell
  comes back as `{ state: 'empty' }`.
- The same applies inside every instance of a repeating group. The TypeScript type is
  `PreparedAnswers`.

### Grids

A `grid` is a table of fixed rows and typed columns (`radio`, `dropdown` or `text`), one answer per
cell. The browser sends `{ [rowCode]: { [columnCode]: string } }`: a choice cell holds an option code
of its column, a text cell its text; empty cells and empty rows are left out.

- **Required is per column**: a column with `required: true` must be answered in every row. The
  grid's own `required` and `completeRequired` are ignored.
- **Errors are per cell**: a missing required cell is `{ message: "Required.", path: [..., gridId,
  rowCode, columnCode] }`, one per cell. A choice cell holding something that is not a code of its
  column gets "Select a valid option."; a text cell over 20,000 characters, "Your answer is too
  long."; a value of the wrong shape, or an unknown row or column code, one "Invalid answer." at
  `[..., gridId]`.
- **A grid is never a condition source**; it can carry its own `enableWhen`.
- In the browser, the error summary shows one entry per required column with missing cells —
  `"Substance use": answer "Frequency" in every row (3 missing).` — linking to the first one.
- When the grid's own width is below 34rem (measured on the grid, not the screen, so a grid in a
  narrow panel or indented in a group gets cards too) each row shows as a card. Class names:
  `zf-grid`, `zf-grid-row`, `zf-grid-card`, `zf-grid-cell`, `zf-grid-cell-label`,
  `zf-grid-cell--invalid`, `zf-grid-column--required`.

Each error's `path` locates it: block ids and 0-based instance positions from the root, e.g.
`["patients", 1, "payments", 0, "amount"]`, or just `[blockId]` outside any repeating group.

The lower-level pieces are exported too, if you need them separately: `assertSchemaIntegrity`,
`validateSubmission`, `getSubmittableAnswers`.

`getVisibleBlockIds` and `getDisplayedBlockIds` cover the **root level only**: every block outside
a repeating group, and the repeating groups themselves. Blocks inside a repeating group are judged
per instance — the same question can be visible in one instance and hidden in another — so they
are not in these sets. `validateSubmission`, `getSubmittableAnswers` and `prepareSubmission` already
apply visibility per instance.

**Keep bodies out of request logs.** Submission bodies — and, if you store server-mode drafts, draft
bodies — carry respondents' answers. Don't write them to request or access logs,
error reports or analytics; log ids such as `formId`, `formVersionId` and `idempotencyKey` instead.

## Drafts and data in the browser

The form keeps a respondent's progress so a refresh doesn't lose it. The author picks a mode in the
builder; the host supplies what that mode needs through the `drafts` prop.

| Mode | Where it's kept | Survives a closed tab | The host provides |
|---|---|---|---|
| `session` (default) | `sessionStorage` of this tab, as plain text, visible answers only | No | nothing (`scope` and `owner` are optional) |
| `device` | IndexedDB, encrypted with your key, plus the tab's copy | Yes, on this device | `scope`, `getKey` |
| `server` (paged forms) | your backend, plus the tab's copy | Yes | `scope`, `loadDraft`, `saveDraft`, `deleteDraft` |
| `off` (set by the host) | nowhere | No, nor a refresh | `drafts={{ mode: 'off' }}` |

```ts
drafts={{
  mode?: 'off',                                         // store nothing; overrides the schema's mode
  scope?: string,                                       // who and whom: `${userId}:${patientId}`
  owner?: string,                                       // the user alone, for clearDrafts({ owner })
  label?: string,                                       // shown in the restore prompt, e.g. "J. Smith"
  getKey?: () => Promise<CryptoKey>,                    // device: your AES-GCM 256 key
  expiresAfterDays?: number,                            // device: default 7, sliding
  loadDraft?: (ref: DraftRef) => Promise<Draft | null>, // server
  saveDraft?: (draft: Draft) => Promise<void>,          // server
  deleteDraft?: (ref: DraftRef) => Promise<void>,       // server
}}
```

- **`scope` must identify the user, and the subject** (patient, visit) whenever one form is filled for
  several. A wrong scope can restore one patient's answers into another's form. It is opaque to the
  package, and only its hash is stored.
- `scope` and `owner` are read once, when the form mounts. To switch to another user or patient, mount
  the form afresh, for example with a new React `key`.
- If a mode can't be used (no scope, no key, no IndexedDB, plain HTTP), the form falls back to session
  mode and calls `onDraftProblem`. Draft problems never block the form.
- Device mode's tab copy holds hidden answers too, as the encrypted draft does. Browsers may write
  `sessionStorage` to disk to restore tabs after a crash.
- Tab entries use the key prefix `@zoworkhq/zoforms:`. Device drafts live in the IndexedDB database
  `zoworkhq-zoforms-drafts`.
- When a form starts keeping progress in a tab, it deletes that tab's copies of its other versions
  (other `formVersionId`s of the same `formId`, for every scope), since nothing restores them once
  the form has changed. A form with a `scope` also deletes the same version's unscoped copy. Copies of
  the same version for another scope are kept, and so are other forms' copies.

**When a saved fill comes back.** A scoped tab copy restores silently. An unscoped one (session mode
with no `scope`) restores silently only on a refresh of the form's own page, on the first form mounted
on that page. Any other time, the respondent chooses first, with nothing of the fill on screen:

> **Continue where you left off?**
> This form was started in this browser tab at 3:40 PM for J. Smith and hasn't been sent.
> \[Continue\] \[Start over\]

A device or server draft found in a fresh tab shows the same choice, with "You have a saved draft from
{date, time}{ for label}."

**`clearDrafts`,** from `@zoworkhq/zoforms/react`, is for the browser, typically at logout:

```js
await clearDrafts({ owner: userId }); // every draft and tab entry saved with this owner
await clearDrafts({ scope });         // every draft and tab entry for this scope
await clearDrafts();                  // everything: the whole device database and every tab entry
```

It deletes from this tab's `sessionStorage` and this device's IndexedDB; server drafts are yours to
delete. It rejects with a `ClearDraftsError` when it can't delete what you asked (`error.failed` names
the storage). It clears storage, not a form on screen: a form still mounted writes its answers again
at its next save, so call it once the form has gone.

### Shared devices

On a clinic tablet, one patient after another can use the same browser tab.

- **Best: nothing stored.** A kiosk should use `drafts={{ mode: 'off' }}`. Nothing is written anywhere,
  and a refresh starts a new form.
- **If you need refresh recovery,** give each respondent a `scope`, or call `clearDrafts()` between
  respondents, after the form has unmounted.
- **Don't rely on reloading.** A reload of the form's own page looks the same whoever presses it, so an
  unscoped copy restores silently after one. A device that reloads that page between respondents
  needs one of the two options above.
- The prompt protects everything else: a link to the form, Back, a route change in your app, and a
  tablet that reloads its home page and then opens the form all ask first. Refreshing the prompt
  shows it again.
- After a reload, if two different forms mount on one page, only the first restores silently; the
  other shows the prompt.

Two mounts of the same form at once share one tab entry. The first keeps it; the second starts empty
and keeps its answers in memory, with a warning in development builds.

## Errors

| What went wrong | The respondent sees | You get |
|---|---|---|
| The form can't be shown: a schema or setting the renderer refuses | "This form can't be shown right now. Please try again later." in its place, on the server and in the browser. The rest of your page renders as usual. | `onRenderError(error, {})` in the browser, once per failure |
| A fault while rendering the form, past those checks | The same message, in the browser | `onRenderError(error, { componentStack })` |
| A submit failed | "Submission failed. Your answers have been kept — please try again.", with focus on it | `onError(error)` |
| Answers failed validation | A summary and a message on each question | nothing: no request is sent |
| A draft problem | Usually nothing, or a short notice | `onDraftProblem(problem)` |

- **What the renderer refuses:** an unsupported `schemaVersion`, a malformed schema, a blank `formId`
  or `formVersionId`, an `endpoint` that isn't secure, or a malformed `validators` array. It checks
  these while it renders, so a server-rendered page carries the message instead of failing: no error
  page and no 500, and a static build such as `next build` succeeds.
- **Logged with `console.error`** in every build: in the browser once per failure, and on the server
  once per render, so it shows in your build and server logs. `onRenderError` is called only in the
  browser.
- A development build also shows the error's text in the message. A production build shows only the
  message.
- **A fault further in,** a bug in the renderer or a schema changed after it was checked, is caught in
  the browser only. On the server React has no error boundaries, so it fails the server render like an
  error in any of your own components.
- These errors don't reach a host error boundary. Use `onRenderError` to report them.
- The form is shown again as soon as `schema`, `endpoint` and `validators` all pass. No new React `key`
  is needed.
- A form that can't be shown is often a newer `schemaVersion` than this package supports: upgrade the
  package.

On the server, `prepareSubmission` **returns** `{ ok: false, errors }` for a bad request, and **throws**
for a bad schema or a bad `validators` array, which are faults in your code rather than in the request.

## Frameworks

**Vite**, and other bundlers: nothing special. Use the [Quick start](#quick-start).

**Next.js App Router.** `/react` is marked `'use client'`, so you can use `FormRenderer` directly in a
server component. Import the stylesheet in a layout:

```tsx
// app/layout.tsx
import type { ReactNode } from 'react';
import '@zoworkhq/zoforms/styles.css';

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
```

```tsx
// app/intake/page.tsx
import { FormRenderer } from '@zoworkhq/zoforms/react';
import type { FormSchema } from '@zoworkhq/zoforms/core';
import schema from './intake-schema.json';

export default function IntakePage() {
  return (
    <main>
      <h1>{schema.title}</h1>
      <FormRenderer schema={schema as FormSchema} endpoint="/api/submit" />
    </main>
  );
}
```

```ts
// app/api/submit/route.ts
import { prepareSubmission } from '@zoworkhq/zoforms/core';
import type { FormSchema } from '@zoworkhq/zoforms/core';
import schema from '../../intake/intake-schema.json';

export async function POST(request: Request) {
  const result = prepareSubmission(schema as FormSchema, await request.json().catch(() => null));
  if (result.ok === false) return Response.json({ errors: result.errors }, { status: 422 });

  // Dedupe on result.submission.idempotencyKey, then store result.submission.
  return Response.json({ ok: true });
}
```

A server component can't pass functions to a client component. For `onSuccess`, `getAuthHeaders`,
`validators` or `getKey`, or to call `clearDrafts`, put the form in your own file that starts with
`'use client'`.

The server renders the empty form, or the "can't be shown" message for a form the renderer refuses
(see [Errors](#errors)). A saved fill is read in the browser, after hydration, so the two always match.

**CommonJS.** `/core` works from `require`:

```js
const { prepareSubmission } = require('@zoworkhq/zoforms/core');
```

`/react` is ES modules only, for bundlers. `require('@zoworkhq/zoforms/react')` fails, as does any
import of the bare package name.

## TypeScript

Types ship with the package. `FormSchema` and the rest come from `@zoworkhq/zoforms/core`,
`FormRendererProps` and `DraftsOptions` from `@zoworkhq/zoforms/react`. Use `moduleResolution` `bundler`,
`node16` or `nodenext`: the older `node` setting doesn't read the package's entry points.

A schema imported from JSON needs a cast when it has conditions, pages, a `drafts` mode or a
`navigation.progressStyle`. TypeScript reads their strings as `string`, not as the exact values
`FormSchema` allows (`"="`, `"page"`, `"device"`, `"bar"` and so on). Other schemas type-check without
one. Cast every schema anyway, so a form that gains a page or a condition keeps compiling. The cast is
safe: the form checks the schema when it renders.

```ts
import type { FormSchema } from '@zoworkhq/zoforms/core';
import data from './intake-schema.json';

const schema = data as FormSchema;
```

## Styling

The default stylesheet is optional: `import '@zoworkhq/zoforms/styles.css'`. Every public class, data
attribute and custom property starts with `zf-`. The `classNames` constant exported from
`@zoworkhq/zoforms/react` lists every class the renderer uses.

Every rule in the stylesheet is wrapped in `:where()`, so it has no specificity, and any plain rule of
your own wins without `!important`. That includes a CSS reset: see
[Styling with CSS resets](#styling-with-css-resets).

```css
.zf-success { border-radius: 0; }
```

**Host hooks.** Put these on an element around the form — a wrapper you render it in:

| Hook | Values | Effect |
|---|---|---|
| `data-zf-theme` | `"dark"` | The dark theme. Opt-in only: it never follows the operating system's setting. |
| `data-zf-density` | `"patient"`, `"standard"` (default), `"dense"` | Control height, spacing and type size. The nearest ancestor with the attribute wins. |
| `data-zf-group-style` | `"box"` | Root-level groups in a light box, instead of the rule down their leading edge. |
| `data-zf-progress-style` | `"bar"`, `"caption"` | Overrides the author's progress style in a paged form, either way. `"bar"` adds a segmented bar above "Step x of y"; the caption always stays. |

```html
<div data-zf-theme="dark" data-zf-density="patient" data-zf-progress-style="bar">
  <!-- <FormRenderer … /> -->
</div>
```

A wrapper rather than the form itself: after a submit, the form is replaced by the success message and
the scores list, and attributes set on the form don't carry over to them. The progress bar and boxed
groups exist only in the stylesheet; without it, those two hooks do nothing.

### Custom properties

Set them on the form or on any element around it — `:root`, your app's wrapper — and they reach the
form, and the success message and scores list shown after a submit. A value nearer the form wins, as
in any cascade: one on the form beats a wrapper's, which beats `:root`'s.

```css
/* Your brand, everywhere */
:root {
  --zf-primary: #6b2fb3;       /* accent: buttons, selected options */
  --zf-primary-soft: #f1eafa;
  --zf-focus-ring: #6b2fb3;
  --zf-font-family: 'Inter', sans-serif;
}

/* One part of your app */
.patient-portal { --zf-max-width: 48rem; }

/* One form: on the wrapper you render it in, so the page after a submit gets it too */
#consent-form { --zf-spacing: 1.25rem; }

/* Or on the form itself — list all three: the success message and scores replace the form */
.zf-form, .zf-success, .zf-scores { --zf-radius: 2px; }
```

A value you set applies in both themes and every density. For a different value in the dark theme,
set it under your own dark selector. It beats a light value set on `:root` or on a wrapper further
out; on the same element, put it after the light value:

```css
[data-zf-theme="dark"] {
  --zf-primary: #b48cf2;
  --zf-primary-soft: #241a33;
  --zf-focus-ring: #b48cf2;
}
```

Set them on the form or anything around it, not on an element inside the form: the stylesheet reads
them on the form, the success message and the scores list, so a value on, say, `.zf-error-summary`
doesn't apply. To change one part of the form, override its own property instead
(`.zf-error-summary { border-left-color: … }`).

An invalid value (`--zf-primary: banana`) does not fall back to the package default: the property is
set, so the declarations that use it are invalid, and the browser uses their inherited or initial
value instead — a Submit button with no background, for instance.

**Colours.** The dark column is the default under `data-zf-theme="dark"`.

| Property | Light | Dark | Used for |
|---|---|---|---|
| `--zf-surface` | `#FFFFFF` | `#151A1E` | Control and tile backgrounds |
| `--zf-surface-sunk` | `#F4F4F2` | `#1B2126` | Hover, notices |
| `--zf-text-color` | `#14181B` | `#E8EAEC` | Text |
| `--zf-muted-color` | `#4A5157` | `#A6AEB5` | Help, table headers, captions |
| `--zf-text-subtle` | `#767D84` | `#7C858D` | Unselected rating stars |
| `--zf-border` | `#E2E2DE` | `#262D33` | Dividers, table rules |
| `--zf-control-border` | `#6B7278` | `#6E7880` | Control edges |
| `--zf-primary` | `#0F5C4A` | `#5DBFA5` | Primary buttons, selected options, the success message |
| `--zf-primary-soft` | `#E6F0ED` | `#12241F` | Selected option and success backgrounds |
| `--zf-on-primary` | `#FFFFFF` | `#0D1114` | Text on primary buttons |
| `--zf-error` | `#9E1B12` | `#FF8D80` | Errors, the required `*` |
| `--zf-error-soft` | `#FBEAE8` | `#2B100D` | Error summary and failure backgrounds |
| `--zf-focus-ring` | `#0F5C4A` | `#5DBFA5` | Focus outline |

**Derived.** By default each follows the properties it is made from, in both themes, including values
you set for those.

| Property | Default | Used for |
|---|---|---|
| `--zf-group-rule` | `--zf-control-border` mixed 45% with `--zf-surface` | The rule down a group's leading edge |
| `--zf-group-box-border` | `--zf-border` | Boxed groups, repeat instances, grid cards |
| `--zf-group-box-radius` | `--zf-radius` | Boxed groups, repeat instances |
| `--zf-group-box-bg` | `--zf-surface-sunk` mixed 60% with `--zf-surface` | Boxed groups, repeat instances |
| `--zf-group-box-padding` | `max(1.5rem, --zf-spacing)`; `1.25rem` on screens up to 40rem | Boxed groups, repeat instances |
| `--zf-progress-current` | `--zf-primary` | The current step of the progress bar |
| `--zf-progress-complete` | `--zf-primary` mixed 65% with `--zf-surface` | Completed steps |
| `--zf-progress-pending` | `--zf-control-border` | Steps to come |

**Shape and type.** The same in both themes.

| Property | Default | Used for |
|---|---|---|
| `--zf-radius` | `6px` | Controls, tiles, buttons, messages |
| `--zf-radius-sm` | `3px` | Rating stars, progress segments |
| `--zf-max-width` | `40rem` | The form's, success message's and scores list's widest |
| `--zf-font-family` | none: your page's font | The form's font |

**Density.** The same in both themes; a value you set replaces every density's.

| Property | Patient | Standard (default) | Dense | Used for |
|---|---|---|---|---|
| `--zf-control-height` | `52px` | `44px` | `34px` | Controls, tiles and buttons (minimum) |
| `--zf-spacing` | `2.25rem` | `1.75rem` | `1.125rem` | Space between blocks |
| `--zf-font-size` | `1.125rem` | `1rem` | `0.875rem` | Text |
| `--zf-font-size-small` | `1rem` | `0.875rem` | `0.8125rem` | Help, captions, error messages |
| `--zf-tile-pad` | `1rem 1.25rem` | `0.75rem 1rem` | `0.5rem 0.75rem` | Option tiles, ranking items |
| `--zf-form-end-space` | `2rem` | `1.5rem` | `1rem` | Space after the buttons, inside the form |

Properties that start with `--_zf-` are the stylesheet's own and not API.

## Styling with CSS resets

A reset that isn't in a CSS layer beats the stylesheet, because the stylesheet's rules have no
specificity. Text fields lose their borders and buttons their backgrounds. A development build warns
once per page when it sees this. If you meant the borderless look, ignore the warning.

**Tailwind 3.** Put its reset in a CSS layer, in the file with your `@tailwind` directives. Rules
outside a layer beat rules inside one, so the package's stylesheet wins and your reset still applies
to the rest of the page:

```css
@layer reset {
  @tailwind base;
}
@tailwind components;
@tailwind utilities;
```

Or turn the reset off, with `corePlugins: { preflight: false }` in `tailwind.config.js`. Your own page
then loses it too.

**Tailwind 4** already puts its reset in a layer. It changes only the error summary's bullets.

**Another reset:** the same idea. Load it inside `@layer`, or add your own rules for the `zf-` classes.

## Content Security Policy

The package needs no inline scripts or styles and doesn't use `eval`, so a strict policy works. This
one covers everything it can do, served from your own origin:

```
default-src 'self';
script-src 'self';
style-src 'self';
img-src 'self' https:;
media-src 'self';
connect-src 'self';
frame-src https://www.youtube-nocookie.com https://player.vimeo.com;
object-src 'none';
base-uri 'none';
```

| Directive | Why |
|---|---|
| `style-src` | The stylesheet, as a file. Add your stylesheet's origin if it's elsewhere. |
| `img-src` | Image blocks. `https:` allows the `https://` sources authors may use; narrow it to your hosts if you can. |
| `media-src` | Video and audio files and captions. Add the hosts they're served from. |
| `connect-src` | The POST to `endpoint`. Add its origin if it's on another one. |
| `frame-src` | YouTube and Vimeo video blocks. Drop it if your forms have none. |

It also works with `require-trusted-types-for 'script'`.

One exception: a paged form rendered on the server has `style="display:none"` on its progress bar, which
`style-src` without `'unsafe-inline'` blocks. The bar then shows, even if the author didn't ask for
one, and it stays after hydration. It's only a visual difference, and a form rendered in the browser
isn't affected.

## Plain HTTP

On a plain-HTTP page other than `localhost`, browsers leave out part of Web Crypto. The form still
works there:

| Feature | On plain HTTP |
|---|---|
| Filling and submitting | Works. |
| Session mode, with or without `scope` | Works. |
| Server mode | Works. |
| Device mode | Can't encrypt, so it falls back to session mode, keeping its scope, and calls `onDraftProblem` with `{ type: 'drafts-unavailable', reason: 'no-webcrypto' }`. Nothing survives a closed tab. |
| `clearDrafts` | Works. |

`endpoint` must still be `https://`, `localhost` or a relative path. A relative path on a plain-HTTP
page sends answers unencrypted, so keep that to a trusted local network.

## Files served by your app

Image, video, captions and audio files have a source that is either an `https://` URL or a path on
your own server starting with a single `/` (e.g. `/images/logo.png`); anything else is not shown. If
your app is served under a sub-path, pass it as `assetBase` so those paths load from under it — with
Vite:

```jsx
<FormRenderer schema={schema} endpoint="/api/submit" assetBase={import.meta.env.BASE_URL} />
```

`https://` sources ignore `assetBase`. YouTube and Vimeo links aren't files and ignore it too. Images
are requested with `referrerPolicy="no-referrer"`.

## Video

A `video` block shows a YouTube or Vimeo link in that service's player, or an `.mp4` / `.webm` file
in the browser's own player. Files follow the same source rule as images (an `https://` URL, or a
path starting with a single `/`, loaded from under `assetBase`). Anything else is not shown. Videos
never autoplay.

**Content Security Policy.** See [Content Security Policy](#content-security-policy): allow the two
players in `frame-src`, and wherever your own video files live in `media-src`.

(Add any other host you serve `.mp4` / `.webm` or `.vtt` captions files from to `media-src`.)

- **Captions on YouTube and Vimeo** are the author's responsibility: add them on that service.
- **Captions on a video file:** a `video` block can carry `captions`, a `.vtt` file under the same
  source rule (an `https://` URL, or a path starting with a single `/`, loaded from under
  `assetBase`). It becomes a captions track that the respondent turns on in the player; captions
  are off by default. Captions that aren't a recognised `.vtt` source, or that fail to load, leave
  the video playing without them. Authors set captions in the builder's Video settings.
- **Captions on another host:** a captions file on a different origin from your page only loads
  with CORS, so the renderer then requests the video with CORS too. Serve both the captions file
  and the video file with `Access-Control-Allow-Origin`, and allow the captions host in
  `media-src`. If the video won't load that way, it is shown once more without captions (with a
  warning in development) rather than not at all.
- **Suggestions on YouTube:** the player is loaded with `rel=0`, which only limits the suggestions
  shown at the end of a video to the same channel. It does not remove them.
- **Referrer for video files:** the players are sent only your site's origin, never the page path.
  A `<video>` element has no referrer setting of its own, so a video file on another host is
  requested with your page's referrer policy. Keep `Referrer-Policy: strict-origin-when-cross-origin`
  (the browser default) or stricter so the page path is never sent.

## Audio

An `audio` block plays an `.mp3`, `.m4a`, `.ogg` or `.wav` file in the browser's own player, full
width up to the form's width. Sources follow the same rule as images (an `https://` URL, or a path
starting with a single `/`, loaded from under `assetBase`); anything else — including streaming
services such as Spotify — is not shown, and neither is a file that fails to load. Audio never
autoplays, loops or starts muted.

**Content Security Policy.** See [Content Security Policy](#content-security-policy): allow wherever
your audio files live in `media-src`.

(Add any other host you serve audio files from.)

- **Referrer:** an `<audio>` element has no referrer setting of its own, so an audio file on
  another host is requested with your page's referrer policy. Keep
  `Referrer-Policy: strict-origin-when-cross-origin` (the browser default) or stricter so the page
  path is never sent.
- **Transcripts:** prerecorded audio needs a text alternative to meet WCAG 2.1 AA (1.2.1). That is
  the form author's responsibility: put a transcript in a `text` block next to the clip.

## Complete answers: `completeRequired`

`completeRequired: true` asks for a question to be answered **in full**. It applies to two types
only:

- **`matrix`:** every row must be answered.
- **`ranking`:** every option must be ranked.

On those two it also makes the question **required**: an empty answer gets "… is required.", and
the question shows the required marker, whatever `required` says. A partial answer gets "Answer
every row of …" or "Rank every option in …".

On **every other type it is ignored**, like any other setting that does not apply there: a
short-text question with `completeRequired: true` and `required: false` is optional. The browser
and `prepareSubmission` apply the same rule.

## Custom validation

Your own checks on any answerable question, written as JavaScript functions in your code. Nothing
about them goes in the schema or the builder.

**Pass the same validators to `prepareSubmission`, or they can be bypassed.** The browser's checks
are only a convenience: anyone can post straight to your endpoint. Keep the validators in one module
and import it in both places:

```ts
// validators.ts — imported by the page and by the backend
import type { FieldValidator } from '@zoworkhq/zoforms/core';

export const validators: FieldValidator[] = [
  {
    field: 'mrn', // block id of an answerable question
    // value is `unknown` to TypeScript: check its type before using it.
    validate: ({ value }) =>
      typeof value === 'string' && /^MRN\d{6}$/.test(value) ? null : 'Enter the MRN as MRN followed by 6 digits.',
  },
  {
    field: 'discharged',
    // Dates are "YYYY-MM-DD", so they compare as strings.
    validate: ({ value, answers }) => {
      const admitted = answers.admitted;
      return typeof value === 'string' && typeof admitted === 'string' && value <= admitted
        ? 'Discharge must be after admission.'
        : null;
    },
  },
];
```

In JavaScript, leave out the type import and the `: FieldValidator[]`.

```jsx
// The page
import { validators } from './validators.js';

<FormRenderer schema={schema} endpoint="/api/submissions" validators={validators} />;
```

```js
// The backend
import { prepareSubmission } from '@zoworkhq/zoforms/core';
import { validators } from './validators.js';

const result = prepareSubmission(schema, body, { validators });
```

`validateSubmission(schema, answers, { validators })` and `getCompletedPageIds(…, { validators })`
take them too.

**What a validator receives:** `{ value, answers, field, path }`.

- **Built-in checks run first, so a validator always receives a well-formed value.** It runs only
  when the question is visible, answered, and passes every built-in check (format, allowed options,
  min/max, `completeRequired`, a grid's required columns). It never sees an empty or invalid answer.
- `value` is in payload form, with codes and never labels: numbers as numbers, dates as
  `"YYYY-MM-DD"`, `checkbox`, `multiselect` and `ranking` as arrays of codes, `matrix` as
  `{ [rowCode]: columnCode }`, `grid` as `{ [rowCode]: { [columnCode]: string } }`.
- `answers` holds the other visible, answered, valid questions it may depend on, by block id: the
  same repeat instance, every enclosing instance, and questions outside any repeat. Never other
  instances.
- Inside a repeating group it runs **once per instance**. `path` is the same as the error's
  `path`, e.g. `["patients", 1, "mrn"]`.
- `value` and `answers` are copies, so changing them has no effect.

**What it returns:** an error message, or `null` / `undefined` when the answer is valid.

- The message is trimmed and shown as **plain text**, never HTML. It appears on the question and in
  the error summary, with the instance prefix ("Patient 2: …"). On a grid, it is shown under the
  grid as a whole.
- Several validators may name one field. They run in array order, and every error is reported. The
  browser shows an identical message only once per question.
- Anything else fails closed: a throw, an empty or whitespace-only string, a number, an object or a
  Promise. The question shows **"This answer couldn't be checked."** and can't be submitted. The
  browser logs the real error with `console.error`, naming the field. On the server, the error
  carries it as `cause` for you to log. `cause` is non-enumerable, so it never appears in
  `JSON.stringify(errors)`.

**Rules for validators:**

- **They must be pure and fast.** In a paged form they run on every render (each keystroke), and on
  flagged questions in any form. Don't log, count or cache anything from inside one.
- **They must not use `window`, `document` or anything else on the page, or make network calls.**
  The same code runs on your server, where none of that exists.
- **Errors only, and synchronous only, in this version.** Warnings and async validators (for
  example, an MRN lookup) are not supported. A returned Promise counts as a failure.
- The `validators` array is checked at mount and whenever you pass a different array, and
  `prepareSubmission` checks it on every call. Each entry must be `{ field, validate }`, where
  `field` is the id of an answerable question and `validate` is a function. Anything else throws a
  `TypeError` naming the entry. Validators are always function references. Nothing is ever
  evaluated from text.
- **`prepareSubmission` is JavaScript**, so in this version only a Node (or other JavaScript)
  backend can enforce validators. A backend in another language can't run them.

## Scoring

A group can carry scores, such as a questionnaire total or a weighted value. The author writes the
formula in the builder; the exported form carries it as a tree that refers to question ids, so this
package never parses formula text.

**Scores are calculated on your server.** `prepareSubmission` calculates every score from the schema
you pass and the validated answers, and returns them as `derived.scores`:

```js
const result = prepareSubmission(schema, body);
if (result.ok === false) return res.status(422).json({ errors: result.errors });

result.derived.scores;
// [
//   { groupId: 'phq', scoreId: 'total', label: 'Total score', path: ['phq'], value: 14 },
//   { groupId: 'meds', scoreId: 'dose', label: 'Daily dose', path: ['meds', 0], value: 2.5 },
//   { groupId: 'meds', scoreId: 'dose', label: 'Daily dose', path: ['meds', 1], value: null, reason: 'unanswered' },
// ]

store(result.submission); // its scores are result.derived.scores
```

- **The browser never sends scores.** Its payload's `derived` is always `{}`. `prepareSubmission`
  never reads `derived`, or anything else score-like, from the request, so a forged score can't get
  in. Store the scores it returns, never anything from the body.
- **Scores are only calculated for a submission that passes validation.** A failed one returns
  `{ ok: false, errors }` and no scores. Scores never cause validation errors.
- **`derived` is always present on a successful result**: `{ scores: [] }` for a form without scores.
- **A score can be `null`, and then it says why**, in `reason`:
  - `"unanswered"`: a question the formula uses was hidden or not answered, and the author chose
    "No score" for that case. (With "Count as 0", an unanswered question counts as 0 instead.)
  - `"invalid"`: the formula divided by zero, or the result isn't a finite number.
- **One result per place the group appears.** A score on a repeating group gives one result per
  instance, and `path` ends with the instance's position (0-based), as in `ValidationError.path`. A
  hidden group, and a repeating group with no instances, give no results.
- **Order:** results follow the form's reading order, instance by instance, the same order as
  validation errors; each group's scores keep their order.
- **Rounding:** only the final value is rounded, to the author's number of decimal places (0 to 4),
  with halves rounded away from zero (2.5 becomes 3, −2.5 becomes −3).

**What respondents see.** If the author turned on "Show to respondent after submit", the renderer
lists that score under the success message after a successful submit, as "Total score: 14" (inside
a repeat: "Patient 2: Total score: 14"). It is never shown while the form is being filled in, nor on
the review page, and a `null` score is not shown. **That value is for display only.** The browser
calculates it with the same function, but the server's value from `prepareSubmission` is the one to
store and act on.

`calculateScores(schema, answers)` is exported from `@zoworkhq/zoforms/core` too, along with the
`Score`, `FormulaNode` and `ScoreResult` types. It is the function `prepareSubmission` uses; call it
only on answers that passed validation.

## Known limits

What this version doesn't do, or does in a way you may need to plan for:

- **Sandboxed iframes need `allow-modals`.** Clear form, and Remove on a repeat entry that has answers,
  ask for confirmation with the browser's own dialog. In a sandboxed iframe without `allow-modals`,
  the browser skips the dialog, so those buttons silently do nothing.
- **Treat a schema as fixed once you've passed it.** Each schema object is checked once. A schema you
  change in place afterwards isn't checked again, so pass a new object instead.
- **`onError` doesn't get the response.** After a non-2xx answer it receives an `Error` such as
  "Submission failed with status 422", so the response body, with your server's errors, can't be read
  from it.
- **The `localhost` exception accepts any scheme.** An absolute `endpoint` on `localhost` or
  `127.0.0.1` is accepted whatever its scheme, not only `http://` and `https://`. The browser then
  refuses to send to a scheme other than those, and the submit fails. `[::1]` and names ending in
  `.localhost` count as other hosts and need `https://`.
- **Numbers as strings on the server.** `prepareSubmission` accepts `"3"` for a scale and `"5"` for a
  rating, and stores them as numbers; the browser's check rejects them. The rendered form never sends
  strings there.
- **A strict Content Security Policy can show the progress bar** on a paged form rendered on the
  server: see [Content Security Policy](#content-security-policy).
- **A video file with captions on another origin** works out its CORS setting from the page's address
  while rendering, so a server render and the browser may disagree for it.
- **A fault inside the form during server rendering** fails the render: see [Errors](#errors).
- **Drafts:** two tabs with the same form and scope keep the last save. In device mode, the save when a
  tab is closed is best effort, and up to about a second of typing can be missing from the draft. See
  [Shared devices](#shared-devices) for what a reload restores.
- **Large forms work, with room to speed up.** With the processor slowed four times, 300 questions on
  one page appear in 1.7 s and the slowest keystroke takes 120 ms; 50 repeat entries appear in 1.0 s.

## Release notes

### 0.29.1: the same tarball on every machine

No code changes. Line endings are now LF everywhere, so the published tarball is the same on every
machine.

### 0.29.0: the package is now `@zoworkhq/zoforms`

**Breaking: your dependency and imports**

- **Renamed from `@zoworkhq/forms` to `@zoworkhq/zoforms`,** for the product's new name, ZoForms.
  There is no package or alias under the old name. Update your dependency and every import:
  - `@zoworkhq/forms/react` → `@zoworkhq/zoforms/react`
  - `@zoworkhq/forms/core` → `@zoworkhq/zoforms/core`
  - `@zoworkhq/forms/styles.css` → `@zoworkhq/zoforms/styles.css`
- `npm pack` now produces `zoworkhq-zoforms-<version>.tgz`.

**Changed: saved progress**

- **The tab's `sessionStorage` entries use the prefix `@zoworkhq/zoforms:`**, and **device drafts
  live in the IndexedDB database `zoworkhq-zoforms-drafts`**. Progress saved by an earlier version is
  not carried over, and the old `zoworkhq-forms-drafts` database is left as it is.

**Changed: messages**

- Console warnings and errors start with `@zoworkhq/zoforms:`, and the "unsupported schemaVersion"
  error names `@zoworkhq/zoforms`.

Classes (`zf-*`), data attributes (`data-zf-*`), custom properties (`--zf-*`), exported names,
schemas, payloads and behaviour are unchanged.

### 0.28.1: the version filled in, refused forms on the server, doc fixes

**Breaking: your server**

- **`prepareSubmission` needs the body's `formVersionId`:** text of 1–256 characters, not blank, or
  exactly your schema's `formVersionId` whatever its length. Any characters are allowed. The rendered
  form has always sent it; a hand-made body without it is now rejected with one "Invalid submission"
  error.

**New**

- **`submission.answeredFormVersionId`:** the version of the form the respondent filled in, exactly
  as sent, next to your schema's `formVersionId`. It's always present, so a record built against an
  older version (`versionMismatch: true`) shows which version was answered. See
  [Server-side use](#server-side-use). The body's `schemaVersion` is still never read.

**Changed: your page**

- **A refused form shows its message during server rendering too.** A static page with a refused form
  no longer fails `next build`, and a dynamic one no longer returns a 500: the page renders with the
  message in place of the form. See [Errors](#errors).
- **`onRenderError` gets `{}` as `info` for a refused schema or setting,** with no `componentStack`:
  nothing below the form rendered. It's still called once per failure, in the browser only.
- **Refusals are logged with `console.error` in every build,** and on the server once per render.
- **No new `key` is needed after a refusal.** The form is shown as soon as `schema`, `endpoint` and
  `validators` all pass.

**Fixed**

- **Starting a form no longer deletes another form's tab copies.** Form `intake` deleted the tab's
  copies of a form whose id started with `intake:`, such as `intake:child`. The `formId` in a key is
  now matched exactly.

**Docs and types**

- `Submission.formVersionId` is required in the type, and `StoredSubmission` has
  `answeredFormVersionId`.
- The section on images is now [Files served by your app](#files-served-by-your-app) and covers video,
  captions and audio files, which `assetBase` applies to as well. Links to `#images-served-by-your-app`
  need the new anchor.
- [TypeScript](#typescript): which schemas need the `as FormSchema` cast.
- The validators example compiles under `strict`, and the scoring example stores `result.submission`.
- New [Known limits](#known-limits), in place of a pointer to a file that isn't in the package.
- Corrected: `maxOccurs` left out means at most 1,000; `clearDrafts` rejects with a `TypeError` for
  bad options, rather than throwing; an unknown block type shows the message; the builder sets video
  captions.

### 0.28.0: ready for clients: shared devices, plain HTTP, strict servers, CommonJS

This release follows a full audit. Read the breaking changes before upgrading.

**Breaking: your server**

- **`prepareSubmission` needs a valid `idempotencyKey` and `submittedAt`.** The rendered form always
  sends them. A hand-made `prepareSubmission(schema, { answers })` is now rejected.
- **Store `result.submission`, not `{ ...body, answers }`.** It's new, and it's the only thing that is
  safe to store: see [Server-side use](#server-side-use).
- **Stored answers are rebuilt.** Extra keys on an answer, and any `value` on an empty answer, are gone.
- **Numbers, dates and times are stricter.** A number is a finite number or a plain decimal string; a
  date and a time are strings, with times held to `00:00`–`23:59`. `[5]`, `"Infinity"`, `"1e400"`,
  `["2024-01-01"]` and `"99:99"` used to pass.
- **A body that isn't an object with `answers` is rejected** with one error instead of throwing.
- **A repeating group with no `maxOccurs` now holds at most 1,000 entries,** and too many are refused
  on the count alone.

**Breaking: schemas**

- **More schemas are refused.** Every label, title, help text, placeholder, content and option label
  must be text; `blocks` and `options` must be lists; and a group may not sit inside 100 or more other
  groups. The error names the block.

**Breaking: your page**

- **Errors no longer reach your error boundary.** The form shows a message in its place and calls the
  new `onRenderError`: see [Errors](#errors).
- **Element ids and radio `name`s have a per-form prefix,** such as `zf-r0-name`, so two forms never
  share one. CSS or tests that use `#name` or `[name="q"]` need a `zf-` class or a label instead.
- **A new `fieldset.zf-fields` sits between the form and its questions.** CSS using `.zf-form > .zf-block`
  needs updating. Without the stylesheet it shows the browser's fieldset border.
- **Submit is `aria-disabled`, not `disabled`, while sending,** so it keeps focus. CSS on
  `.zf-submit:disabled` needs `[aria-disabled="true"]` too.
- **Focus moves in three new places:** to the failure message after a failed submit, to Submit when
  Enter is pressed in a field, and to the start of the form after Start over.
- **Counts follow the respondent's locale:** "You can add up to 1,000.", "Step 2 of 3", ranks and stars.

**Breaking: drafts**

- **Session mode no longer stores hidden answers.** They stay in memory while the form is open, but a
  refresh loses them. Device and server modes keep them, as before.
- **An unscoped tab copy now asks first,** unless the page was refreshed: see
  [Shared devices](#shared-devices). A tab open across this upgrade asks too, because older copies have
  no address.
- **`clearDrafts()` with no options also removes unscoped tab entries.**
- **`clearDrafts` can reject,** with a `ClearDraftsError`, rather than resolving without clearing.
- **Server mode now works on plain HTTP** instead of falling back, and device mode's fallback there
  keeps its scope.
- **The failed-save notice says when the next save happens,** because nothing retries in the background.

**Breaking: the package**

- **Peers are `react` and `react-dom` `^18.0.0 || ^19.0.0`.** `react-dom` is new, and the old `>=18`
  also allowed versions nobody has tested.
- **`engines` is `node >= 20`,** and `./core` now has `import` and `require` conditions.

**New**

- `drafts={{ mode: 'off' }}` stores nothing anywhere, and session mode takes `scope` and `owner`.
- `onRenderError`, `ClearDraftsError`, and `result.submission` with its type `StoredSubmission`.
- The form works on plain HTTP: see [Plain HTTP](#plain-http).
- `require('@zoworkhq/forms/core')` works, and `/react` is marked `'use client'` for the Next.js App
  Router.
- While sending, the fields can't be edited and a polite status says "Sending…". New classes:
  `zf-fields`, `zf-sending`, `zf-unavailable`, `zf-unavailable-detail`.
- A development warning when a CSS reset beats the stylesheet: see
  [Styling with CSS resets](#styling-with-css-resets).
- The README now covers install to a validated submission, drafts, errors, frameworks, TypeScript, CSP
  and plain HTTP.

**Known limits:** see [Known limits](#known-limits).

### 0.27.0: safer link answers, clearer error summary, clearing answers, video captions

- **Security: a Link answer must be an `https://` or `http://` address.** Until now anything the
  URL parser understood passed, including `javascript:alert(1)`, `data:…`, `mailto:…` and `ftp:…`.
  Now only `https:` and `http:` addresses with a host and no `user@` credentials pass, in the browser
  and in `prepareSubmission` / `validateSubmission`, decided by parsing. The message is unchanged:
  "Enter a valid URL, including https://.". If you show link answers as links, upgrade.
- **An answer that holds nothing is no answer.** A hand-made `{ state: "answered" }` with an empty
  array, an empty object, or an empty or whitespace-only string now counts as `{ state: "empty" }`
  for every question type: a required question rejects it with `"<label>" is required.`, conditions
  and scores treat it as unanswered, and `prepareSubmission` returns it as empty. Before, `[]` passed
  a required Checkbox, Multiselect or Ranking and `{}` passed a required Matrix. The rendered form
  never sent these values.
- **Every error summary line names its question:** `"Email": Enter a valid email address.`, and in
  a repeating group `Child 1: "Age": Must be at most 17.` Messages that already name the question
  (`"Age" is required.` and the "every row" / "every option" messages) and grid lines are unchanged,
  and so are the messages beside each field and `ValidationError.message`. Your validators' messages
  get the label in the summary too.
- **Clearing an answer.** Pressing the pressed star clears a Rating, and choosing a Matrix row's
  selected column again clears that row. An optional Choice or Matrix shows **Clear selection** while
  it has an answer, and an answered radio cell in an optional grid column shows **Clear**: the
  keyboard's way to clear, since browsers ignore Space on a checked radio. New class:
  `zf-clear-selection`.
- **Captions on video files:** a `video` block's optional `captions` (a `.vtt` file) becomes a
  captions track, off until the respondent turns it on. See [Video](#video) for captions on another
  host (CORS) and your Content Security Policy.
- **Rating buttons are named "1 star", "2 stars" … "5 stars"** (was "1 stars").
- **Matrix:** the empty corner of the header row is a `td`, not an empty `th`. Host CSS aimed at
  `.zf-matrix thead th` no longer matches it.
- **README:** [Showing the form](#showing-the-form): your page shows the form's `title` and
  `description` and owns the `h1`; the schema type now has `description?: string`. The grid's card
  layout starts below 34rem of the grid's own width (the README said 40rem of the screen).

### 0.26.0: custom properties work from `:root` or any wrapper

- **Set `--zf-*` properties on `:root`, a wrapper, or the form.** Until now the stylesheet declared its
  defaults on `.zf-form`, `.zf-success` and `.zf-scores`, so a value set on `:root` or a wrapper
  silently did nothing. Values set on those three classes keep working unchanged.
- **Behaviour change: a `--zf-*` value set on an element inside the form no longer applies** — for
  example `.zf-error-summary { --zf-error: … }`. Set it on the form or any element around it, or
  override the element's own property instead (`.zf-error-summary { border-left-color: … }`).
- A value you set applies in both themes and every density. For a different dark value, set it under
  your own `[data-zf-theme="dark"]` selector. See [Custom properties](#custom-properties).
- Put `data-zf-*` hooks on a wrapper: the form is replaced on submit, and attributes set on it don't
  carry over to the success message and scores list.
- Every public custom property is now listed with its light and dark defaults. Names and defaults are
  unchanged: with nothing set, the form looks exactly as in 0.25.0. Properties starting with `--_zf-`
  are the stylesheet's own and not API.

### 0.25.0: the public prefix is now `zf-`

- **The package is `@zoworkhq/forms`.**
- **Every class, data attribute and custom property now starts with `zf-` (formerly `yf-`).**
  Classes are `zf-form`, `zf-group`, `zf-success` and so on. The data attributes are
  `data-zf-theme`, `data-zf-density`, `data-zf-group-style` and `data-zf-progress-style`. Custom
  properties are `--zf-…`, including the `--zf-font-family` hook. Update any host CSS and any
  attributes your page sets. See [Styling](#styling).
- **The tab's `sessionStorage` entries use the prefix `@zoworkhq/forms:`**, and **device drafts
  live in the IndexedDB database `zoworkhq-forms-drafts`**. Progress saved by an earlier version is
  not carried over.
- Behaviour, schemas, payloads and the API are unchanged.

### 0.24.0: the package is now `@zoworkhq/forms`

- **Renamed from `@yourco/forms` to `@zoworkhq/forms`.** Nothing else about the API changes. Update
  your dependency and every import:
  - `@yourco/forms/react` → `@zoworkhq/forms/react`
  - `@yourco/forms/core` → `@zoworkhq/forms/core`
  - `@yourco/forms/styles.css` → `@zoworkhq/forms/styles.css`
- `npm pack` now produces `zoworkhq-forms-<version>.tgz`.
- Console warnings and the "unsupported schemaVersion" error now say `@zoworkhq/forms`.
- **Saved progress is unaffected.** The tab's `sessionStorage` entries (prefix `@yourco/forms:`) and
  device drafts (IndexedDB database `yourco-forms-drafts`) keep their names, so answers saved by an
  earlier version are still found. Those names are part of the drafts contract.
- Behaviour, schemas, payloads and class names (`yf-*`) are unchanged.

### 0.23.1: the scores list lines up with the success message

- **The scores list no longer inherits a host's centred text.** In a host whose page centres its
  text (for example `#root { text-align: center }`), the `.yf-scores` list after the success message
  was centred, with its bullets left at the edge. It now sets its own `text-align: start`, as
  `.yf-form` and `.yf-success` already do.
- **No bullets, and aligned with the message.** Each score line starts under the message's ✓, and
  the list is exactly as wide as the message. If your CSS styles `.yf-scores`, check it against the
  new look.
- The `<ul class="yf-scores">` now has `role="list"`, so screen readers that drop list semantics
  when the bullets are removed (VoiceOver in Safari) still announce it as a list.
- Nothing else changes: scores, payloads and the success message are as in 0.23.0.

### 0.23.0: scoring (contract §17)

- **Scores.** Groups can carry scores (see [Scoring](#scoring)). `prepareSubmission` returns them as
  `derived.scores`, and the renderer lists the ones meant for respondents after a successful submit,
  in a new `<ul class="yf-scores">` after the success message.
- **`prepareSubmission`'s successful result now always has `derived`**, `{ scores: [] }` when the
  form has no scores. If your tests compare the whole result object, add it there.
- **Focus moves to the success message after a successful submit**, on every form. Until now the
  form, and the button that had focus, simply disappeared, so focus fell to the page body. The
  message now has `tabindex="-1"` and takes focus; its markup and text are otherwise unchanged. Like
  a page title, it shows no focus ring.
- New class name: `yf-scores` (additive).
- New schema fields, checked at mount: `scores` on groups and `score` on options and matrix
  columns. Forms without them behave exactly as before. Validation, payloads and drafts are
  unchanged.

### 0.22.0: the required marker and ranking announcements (contract §7)

- **The required marker is no longer part of any accessible name.** The `*` used to be a CSS
  `::after` on the question's label or legend, and Chromium read it out: a required ranking
  question named "Priorities" was announced "Priorities star", and an exact-name lookup failed. It
  is now an empty `<span class="yf-required" aria-hidden="true">` at the end of the label or
  legend (and of a required grid column's header and card labels), and the stylesheet draws the
  " *" in it. It looks the same. The label's text is unchanged, so lookups by label text still
  match the label alone. As before, without the stylesheet there is no marker.
- **If your CSS styles `.yf-block--required .yf-label::after`, move it to `.yf-required::after`.**
  The old rule is gone from the package stylesheet. A host rule that hid the marker on the old
  selector no longer hides it, and one that set its own `content` there now shows a second marker.
  The same applies to `th.yf-grid-column--required::after` and
  `.yf-grid-column--required > .yf-grid-cell-label::after`. `yf-block--required` and
  `yf-grid-column--required` are still rendered as before.
- **"Required" is still exposed**: native `required` on inputs, selects and textareas;
  `aria-required` on grid cells; and, on the questions rendered as a fieldset (choice, checkbox,
  multiselect, scale, rating, ranking, matrix), a hidden "Required" description listed first in
  the fieldset's `aria-describedby`.
- **Ranking:** each option button is named by its label alone and described by its rank
  ("Ranked 2 of 3", or "Not ranked"). A polite `role="status"` line in each ranking question
  (one per repeat instance), visually hidden, announces every change: "Speed ranked 2 of 3.", or
  "Speed unranked. Order: 1 Cost, 2 Quality."
- New class names: `yf-required`, `yf-ranking-status` (additive).
- Validation, values, payloads and layout are unchanged.
