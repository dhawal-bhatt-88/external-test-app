# @yourco/forms

Renders a builder-exported form schema in a React app, validates it, and posts it to your API.

## Images served by your app

An `image` block's source is either an `https://` URL or a path on your own server starting with a
single `/` (e.g. `/images/logo.png`); anything else is not shown. If your app is served under a
sub-path, pass it as `assetBase` so those paths load from under it — with Vite:

```jsx
<FormRenderer schema={schema} endpoint="/api/submit" assetBase={import.meta.env.BASE_URL} />
```

`https://` sources ignore `assetBase`. Images are requested with `referrerPolicy="no-referrer"`.

## Video

A `video` block shows a YouTube or Vimeo link in that service's player, or an `.mp4` / `.webm` file
in the browser's own player. Files follow the same source rule as images (an `https://` URL, or a
path starting with a single `/`, loaded from under `assetBase`). Anything else is not shown. Videos
never autoplay.

**Content Security Policy.** If your app sends a CSP, allow the two players, and wherever your own
video files live:

```
frame-src https://www.youtube-nocookie.com https://player.vimeo.com;
media-src 'self';
```

(Add any other host you serve `.mp4` / `.webm` files from to `media-src`.)

- **Captions** are the author's responsibility: add them on YouTube or Vimeo. Video files have no
  caption support yet.
- **Suggestions on YouTube:** the player is loaded with `rel=0`, which only limits the suggestions
  shown at the end of a video to the same channel. It does not remove them.
- **Referrer for video files:** the players are sent only your site's origin, never the page path.
  A `<video>` element has no referrer setting of its own, so a video file on another host is
  requested with your page's referrer policy. Keep `Referrer-Policy: strict-origin-when-cross-origin`
  (the browser default) or stricter so the page path is never sent.

## Audio

An `audio` block plays an `.mp3`, `.m4a`, `.ogg` or `.wav` file in the browser's own player, full
width up to the form's width. Sources follow the same rule as images (an `https://` URL, or a path
starting with a single `/`, loaded from under `assetBase`); anything else — including streaming
services such as Spotify — is not shown, and neither is a file that fails to load. Audio never
autoplays, loops or starts muted.

**Content Security Policy.** If your app sends a CSP, allow wherever your audio files live:

```
media-src 'self';
```

(Add any other host you serve audio files from.)

- **Referrer:** an `<audio>` element has no referrer setting of its own, so an audio file on
  another host is requested with your page's referrer policy. Keep
  `Referrer-Policy: strict-origin-when-cross-origin` (the browser default) or stricter so the page
  path is never sent.
- **Transcripts:** prerecorded audio needs a text alternative to meet WCAG 2.1 AA (1.2.1). That is
  the form author's responsibility: put a transcript in a `text` block next to the clip.

## Complete answers: `completeRequired`

`completeRequired: true` asks for a question to be answered **in full**. It applies to two types
only:

- **`matrix`:** every row must be answered.
- **`ranking`:** every option must be ranked.

On those two it also makes the question **required**: an empty answer gets "… is required.", and
the question shows the required marker, whatever `required` says. A partial answer gets "Answer
every row of …" or "Rank every option in …".

On **every other type it is ignored**, like any other setting that does not apply there: a
short-text question with `completeRequired: true` and `required: false` is optional. The browser
and `prepareSubmission` apply the same rule.

## Server-side use

Never trust the browser's payload. On your server, pass it to `prepareSubmission` from
`@yourco/forms/core` (no React needed) with the same schema the form was rendered from:

```js
import { prepareSubmission } from '@yourco/forms/core';

const result = prepareSubmission(schema, body);

if (!result.ok) {
  return res.status(422).json({ errors: result.errors }); // [{ blockId, message, path }]
}
if (result.versionMismatch) {
  log.warn('submission built against a different form version', body.formId, body.formVersionId);
}
store({ ...body, answers: result.answers }); // store these answers, never body.answers
```

`prepareSubmission`:

- **checks the schema** and throws if it is malformed (unknown type, bad condition, unsupported
  `schemaVersion`) — a fault in your schema, not in the payload;
- **validates** every visible question: required, formats, allowed options. Options are coded
  (`{ code, label }`): the browser sends **codes only**, and membership compares codes exactly as
  stored. A label, a code in the wrong case, or a `{ code, label }` object in place of a code is
  rejected with the usual message ("Select a valid option.", or "Invalid answer." for a matrix). Free-text answers (short,
  long, email, phone, link) must be strings of at most `MAX_FREE_TEXT_LENGTH` (20,000) characters;
  email, phone and link formats are checked on the trimmed text;
- **treats whitespace-only free text as unanswered**: a required one is rejected, and an optional one
  comes back as `{ state: 'empty' }`. Any other text comes back exactly as sent — never trimmed;
- **returns the answers to store**: visible answerable questions only. Answers to hidden or unknown
  questions are stripped, never a reason to reject;
- **normalises numbers**: a numeric string such as `"500"` answering a number, scale or rating
  question comes back as `500`. A non-numeric string is still rejected;
- **returns coded answers with their labels**, looked up from the schema you pass — never from the
  request — so stored submissions are readable without the schema (see below). Labels are plain
  text; treat them as data and escape them wherever you display them;
- **rejects a malformed answer value**: every answer must be `{ state: 'empty' }` or
  `{ state: 'answered', value }`. Anything else under a visible question's id — `null`, a bare value,
  a missing or unknown `state` — is rejected with "Invalid answer.", whatever the question type;
- **checks grids cell by cell** (see below): a required column must be answered in every row, and
  each missing cell is its own error;
- **handles repeating groups**: a repeating group's answer is an array of instance objects under its
  own id, each built by these same rules (nested repeating groups are arrays inside it). Every rule
  above applies per instance. A visible repeating group whose value is not an array, has an
  instance that is not an object, or has fewer than `minOccurs` / more than `maxOccurs` instances is
  rejected with "Invalid answer.";
- **runs your own validators** when you pass them as `prepareSubmission(schema, body, { validators })`
  (see [Custom validation](#custom-validation));
- **calculates scores** and returns them as `derived.scores` (see [Scoring](#scoring)). Anything
  score-like in the request is ignored;
- **flags `versionMismatch`** when the payload's `formId` or `formVersionId` differs from the schema's.
  Whether to refuse such a payload is your call.

### What `prepareSubmission` returns for coded options

`choice`, `dropdown`, `checkbox`, `multiselect`, `ranking` and `matrix` answers come back labelled.
Every other answer is returned as it was (after the normalisation above):

```json
{
  "smoker":   { "state": "answered", "value": { "code": "former", "label": "Former smoker" } },
  "symptoms": { "state": "answered", "value": [
    { "code": "F32.1", "label": "Low mood" },
    { "code": "sleep", "label": "Poor sleep" }
  ] },
  "phq":      { "state": "answered", "value": [
    { "row": { "code": "interest", "label": "Little interest" }, "column": { "code": "several", "label": "Several days" } }
  ] },
  "age":      { "state": "answered", "value": 42 }
}
```

- `choice`, `dropdown`: `{ code, label }`.
- `checkbox`, `multiselect`, `ranking`: `[{ code, label }, …]`, in the submitted order.
- `matrix`: `[{ row, column }, …]`, answered rows only, in the schema's row order.
- `grid`: `[{ row, cells: [{ column, value }, …] }, …]` (type `GridRowAnswer[]`): answered rows
  only, in row order, each with its answered cells in column order. A radio or dropdown cell's
  `value` is `{ code, label }`; a text cell's is the text as typed. A grid with no answered cell
  comes back as `{ state: 'empty' }`.
- The same applies inside every instance of a repeating group. The TypeScript type is
  `PreparedAnswers`.

### Grids

A `grid` is a table of fixed rows and typed columns (`radio`, `dropdown` or `text`), one answer per
cell. The browser sends `{ [rowCode]: { [columnCode]: string } }`: a choice cell holds an option code
of its column, a text cell its text; empty cells and empty rows are left out.

- **Required is per column**: a column with `required: true` must be answered in every row. The
  grid's own `required` and `completeRequired` are ignored.
- **Errors are per cell**: a missing required cell is `{ message: "Required.", path: [..., gridId,
  rowCode, columnCode] }`, one per cell. A choice cell holding something that is not a code of its
  column gets "Select a valid option."; a text cell over 20,000 characters, "Your answer is too
  long."; a value of the wrong shape, or an unknown row or column code, one "Invalid answer." at
  `[..., gridId]`.
- **A grid is never a condition source**; it can carry its own `enableWhen`.
- In the browser, the error summary shows one entry per required column with missing cells —
  `"Substance use": answer "Frequency" in every row (3 missing).` — linking to the first one.
- Below the stylesheet's narrow breakpoint (40rem) each row shows as a card. Class names:
  `yf-grid`, `yf-grid-row`, `yf-grid-card`, `yf-grid-cell`, `yf-grid-cell-label`,
  `yf-grid-cell--invalid`, `yf-grid-column--required`.

Each error's `path` locates it: block ids and 0-based instance positions from the root, e.g.
`["patients", 1, "payments", 0, "amount"]`, or just `[blockId]` outside any repeating group.

The lower-level pieces are exported too, if you need them separately: `assertSchemaIntegrity`,
`validateSubmission`, `getSubmittableAnswers`.

`getVisibleBlockIds` and `getDisplayedBlockIds` cover the **root level only**: every block outside
a repeating group, and the repeating groups themselves. Blocks inside a repeating group are judged
per instance — the same question can be visible in one instance and hidden in another — so they
are not in these sets. `validateSubmission`, `getSubmittableAnswers` and `prepareSubmission` already
apply visibility per instance.

**Keep bodies out of request logs.** Submission bodies — and, if you store server-mode drafts, draft
bodies — carry the respondent's answers, which are PHI. Don't write them to request or access logs,
error reports or analytics; log ids such as `formId`, `formVersionId` and `idempotencyKey` instead.

## Custom validation

Your own checks on any answerable question, written as JavaScript functions in your code. Nothing
about them goes in the schema or the builder.

**Pass the same validators to `prepareSubmission`, or they can be bypassed.** The browser's checks
are only a convenience: anyone can post straight to your endpoint. Keep the validators in one module
and import it in both places:

```js
// validators.js — imported by the page and by the backend
export const validators = [
  {
    field: 'mrn', // block id of an answerable question
    validate: ({ value }) => (/^MRN\d{6}$/.test(value) ? null : 'Enter the MRN as MRN followed by 6 digits.'),
  },
  {
    field: 'discharged',
    // Dates are "YYYY-MM-DD", so they compare as strings.
    validate: ({ value, answers }) =>
      answers.admitted && value <= answers.admitted ? 'Discharge must be after admission.' : null,
  },
];
```

```jsx
// The page
import { validators } from './validators.js';

<FormRenderer schema={schema} endpoint="/api/submissions" validators={validators} />;
```

```js
// The backend
import { prepareSubmission } from '@yourco/forms/core';
import { validators } from './validators.js';

const result = prepareSubmission(schema, body, { validators });
```

`validateSubmission(schema, answers, { validators })` and `getCompletedPageIds(…, { validators })`
take them too.

**What a validator receives:** `{ value, answers, field, path }`.

- **Built-in checks run first, so a validator always receives a well-formed value.** It runs only
  when the question is visible, answered, and passes every built-in check (format, allowed options,
  min/max, `completeRequired`, a grid's required columns). It never sees an empty or invalid answer.
- `value` is in payload form, with codes and never labels: numbers as numbers, dates as
  `"YYYY-MM-DD"`, `checkbox`, `multiselect` and `ranking` as arrays of codes, `matrix` as
  `{ [rowCode]: columnCode }`, `grid` as `{ [rowCode]: { [columnCode]: string } }`.
- `answers` holds the other visible, answered, valid questions it may depend on, by block id: the
  same repeat instance, every enclosing instance, and questions outside any repeat. Never other
  instances.
- Inside a repeating group it runs **once per instance**. `path` is the same as the error's
  `path`, e.g. `["patients", 1, "mrn"]`.
- `value` and `answers` are copies, so changing them has no effect.

**What it returns:** an error message, or `null` / `undefined` when the answer is valid.

- The message is trimmed and shown as **plain text**, never HTML. It appears on the question and in
  the error summary, with the instance prefix ("Patient 2: …"). On a grid, it is shown under the
  grid as a whole.
- Several validators may name one field. They run in array order, and every error is reported. The
  browser shows an identical message only once per question.
- Anything else fails closed: a throw, an empty or whitespace-only string, a number, an object or a
  Promise. The question shows **"This answer couldn't be checked."** and can't be submitted. The
  browser logs the real error with `console.error`, naming the field. On the server, the error
  carries it as `cause` for you to log. `cause` is non-enumerable, so it never appears in
  `JSON.stringify(errors)`.

**Rules for validators:**

- **They must be pure and fast.** In a paged form they run on every render (each keystroke), and on
  flagged questions in any form. Don't log, count or cache anything from inside one.
- **They must not use `window`, `document` or anything else on the page, or make network calls.**
  The same code runs on your server, where none of that exists.
- **Errors only, and synchronous only, in this version.** Warnings and async validators (for
  example, an MRN lookup) are not supported. A returned Promise counts as a failure.
- The `validators` array is checked at mount and whenever you pass a different array, and
  `prepareSubmission` checks it on every call. Each entry must be `{ field, validate }`, where
  `field` is the id of an answerable question and `validate` is a function. Anything else throws a
  `TypeError` naming the entry. Validators are always function references. Nothing is ever
  evaluated from text.
- **`prepareSubmission` is JavaScript**, so in this version only a Node (or other JavaScript)
  backend can enforce validators. A backend in another language can't run them.

## Scoring

A group can carry scores, such as a questionnaire total or a weighted value. The author writes the
formula in the builder; the exported form carries it as a tree that refers to question ids, so this
package never parses formula text.

**Scores are calculated on your server.** `prepareSubmission` calculates every score from the schema
you pass and the validated answers, and returns them as `derived.scores`:

```js
const result = prepareSubmission(schema, body);
if (!result.ok) return res.status(422).json({ errors: result.errors });

result.derived.scores;
// [
//   { groupId: 'phq', scoreId: 'total', label: 'Total score', path: ['phq'], value: 14 },
//   { groupId: 'meds', scoreId: 'dose', label: 'Daily dose', path: ['meds', 0], value: 2.5 },
//   { groupId: 'meds', scoreId: 'dose', label: 'Daily dose', path: ['meds', 1], value: null, reason: 'unanswered' },
// ]

store({ ...body, answers: result.answers, scores: result.derived.scores });
```

- **The browser never sends scores.** Its payload's `derived` is always `{}`. `prepareSubmission`
  never reads `derived`, or anything else score-like, from the request, so a forged score can't get
  in. Store the scores it returns, never anything from the body.
- **Scores are only calculated for a submission that passes validation.** A failed one returns
  `{ ok: false, errors }` and no scores. Scores never cause validation errors.
- **`derived` is always present on a successful result**: `{ scores: [] }` for a form without scores.
- **A score can be `null`, and then it says why**, in `reason`:
  - `"unanswered"`: a question the formula uses was hidden or not answered, and the author chose
    "No score" for that case. (With "Count as 0", an unanswered question counts as 0 instead.)
  - `"invalid"`: the formula divided by zero, or the result isn't a finite number.
- **One result per place the group appears.** A score on a repeating group gives one result per
  instance, and `path` ends with the instance's position (0-based), as in `ValidationError.path`. A
  hidden group, and a repeating group with no instances, give no results.
- **Order:** results follow the form's reading order, instance by instance, the same order as
  validation errors; each group's scores keep their order.
- **Rounding:** only the final value is rounded, to the author's number of decimal places (0 to 4),
  with halves rounded away from zero (2.5 becomes 3, −2.5 becomes −3).

**What respondents see.** If the author turned on "Show to respondent after submit", the renderer
lists that score under the success message after a successful submit, as "Total score: 14" (inside
a repeat: "Patient 2: Total score: 14"). It is never shown while the form is being filled in, nor on
the review page, and a `null` score is not shown. **That value is for display only.** The browser
calculates it with the same function, but the server's value from `prepareSubmission` is the one to
store and act on.

`calculateScores(schema, answers)` is exported from `@yourco/forms/core` too, along with the
`Score`, `FormulaNode` and `ScoreResult` types. It is the function `prepareSubmission` uses; call it
only on answers that passed validation.

## Release notes

### 0.23.1: the scores list lines up with the success message

- **The scores list no longer inherits a host's centred text.** In a host whose page centres its
  text (for example `#root { text-align: center }`), the `.yf-scores` list after the success message
  was centred, with its bullets left at the edge. It now sets its own `text-align: start`, as
  `.yf-form` and `.yf-success` already do.
- **No bullets, and aligned with the message.** Each score line starts under the message's ✓, and
  the list is exactly as wide as the message. If your CSS styles `.yf-scores`, check it against the
  new look.
- The `<ul class="yf-scores">` now has `role="list"`, so screen readers that drop list semantics
  when the bullets are removed (VoiceOver in Safari) still announce it as a list.
- Nothing else changes: scores, payloads and the success message are as in 0.23.0.

### 0.23.0: scoring (contract §17)

- **Scores.** Groups can carry scores (see [Scoring](#scoring)). `prepareSubmission` returns them as
  `derived.scores`, and the renderer lists the ones meant for respondents after a successful submit,
  in a new `<ul class="yf-scores">` after the success message.
- **`prepareSubmission`'s successful result now always has `derived`**, `{ scores: [] }` when the
  form has no scores. If your tests compare the whole result object, add it there.
- **Focus moves to the success message after a successful submit**, on every form. Until now the
  form, and the button that had focus, simply disappeared, so focus fell to the page body. The
  message now has `tabindex="-1"` and takes focus; its markup and text are otherwise unchanged. Like
  a page title, it shows no focus ring.
- New class name: `yf-scores` (additive).
- New schema fields, checked at mount: `scores` on groups and `score` on options and matrix
  columns. Forms without them behave exactly as before. Validation, payloads and drafts are
  unchanged.

### 0.22.0: the required marker and ranking announcements (contract §7)

- **The required marker is no longer part of any accessible name.** The `*` used to be a CSS
  `::after` on the question's label or legend, and Chromium read it out: a required ranking
  question named "Priorities" was announced "Priorities star", and an exact-name lookup failed. It
  is now an empty `<span class="yf-required" aria-hidden="true">` at the end of the label or
  legend (and of a required grid column's header and card labels), and the stylesheet draws the
  " *" in it. It looks the same. The label's text is unchanged, so lookups by label text still
  match the label alone. As before, without the stylesheet there is no marker.
- **If your CSS styles `.yf-block--required .yf-label::after`, move it to `.yf-required::after`.**
  The old rule is gone from the package stylesheet. A host rule that hid the marker on the old
  selector no longer hides it, and one that set its own `content` there now shows a second marker.
  The same applies to `th.yf-grid-column--required::after` and
  `.yf-grid-column--required > .yf-grid-cell-label::after`. `yf-block--required` and
  `yf-grid-column--required` are still rendered as before.
- **"Required" is still exposed**: native `required` on inputs, selects and textareas;
  `aria-required` on grid cells; and, on the questions rendered as a fieldset (choice, checkbox,
  multiselect, scale, rating, ranking, matrix), a hidden "Required" description listed first in
  the fieldset's `aria-describedby`.
- **Ranking:** each option button is named by its label alone and described by its rank
  ("Ranked 2 of 3", or "Not ranked"). A polite `role="status"` line in each ranking question
  (one per repeat instance), visually hidden, announces every change: "Speed ranked 2 of 3.", or
  "Speed unranked. Order: 1 Cost, 2 Quality."
- New class names: `yf-required`, `yf-ranking-status` (additive).
- Validation, values, payloads and layout are unchanged.
